package com.cg.smms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingMallManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingMallManagementSystemApplication.class, args);
	}

}
